# mltools

Machine Learning functions aiming to help in the Machine Learning course at ICAI

## Installation

```bash
$ pip install mltools
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`mltools` was created by Jaime Pizarroso. It is licensed under the terms of the GNU General Public License v3.0 license.

## Credits

`mltools` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
